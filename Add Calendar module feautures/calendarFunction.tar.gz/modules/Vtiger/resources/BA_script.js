$(function(){
    applyCalendarAdvanceFunctions();
});

function applyCalendarAdvanceFunctions(){
    var moduleName = app.getModuleName();
    var moduleView = app.getViewName();
    if(moduleName == 'Calendar' && moduleView == 'List'){
        var newFunctionList = '<li class="divider"></li> '+
                                '<li> <a class="ba_advance_function" data-operation="copy" > Copy task </a> </li>' +
                                '<li> <a class="ba_advance_function" data-operation="print" > Quick print </a> </li>' +
                                '<li> <a class="ba_advance_function" data-operation="change_status" > Mark task as completed </a> </li>' +
                                '<li> <a class="ba_advance_function" data-operation="rename" > Rename task </a> </li>' +
                                '<li> <a class="ba_advance_function" data-operation="postpone" > Move task X minute / X days </a> </li>' +
                                '<li> <a class="ba_advance_function" data-operation="change_owner" > Assign to </a> </li>' ;

        $('.listViewMassActions ul ').append( newFunctionList );

        var modal = ' <div class="modal hide fade" id="ba_custom_cal_modal">    <div class="modal-header">  <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>  <h3 id = "ba_cal_modal_header" >  </h3>  </div>  <div class="modal-body" id="ba_cal_modal_body">  <h3> Loading... </h3> </div> <div class="modal-footer"> <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> <button type="button" class="btn btn-primary ba-modal-main_btn"> Save </button>   </div></div>';
        $('body').append(modal);
    }
}

// Action event
$(document).on('click' , '.ba_advance_function' , function(){
   var selectedRecords = [];
    $("input:checkbox[class=listViewEntriesCheckBox]:checked").each(function(){
        selectedRecords.push($(this).val());
    });
    if(selectedRecords.length == 0){
        alert("Please select at least one record");
        return false;
    }
    var operation = $(this).data('operation');

    if(operation == 'rename'){
        $('#ba_cal_modal_header').html('Rename Task');
        var inputBox = '<div> <label> Enter new name  </lable> <input type="text" id="new_task_name" name="new_task_name" value="" /> </div>'
        $('#ba_cal_modal_body').html(inputBox);
        $('.ba-modal-main_btn').attr('id' , 'save_new_name');
        $('#ba_custom_cal_modal').modal('toggle');
        return false;
    } else if(operation == 'change_owner'){
        $('#ba_cal_modal_header').html('Change Assign to ');
        var listUsers = getUserList();
        selectBox = '<label> Assign to </label> <select name="new_owner" id="new_owner"> '+listUsers+' </select>';
        $('#ba_cal_modal_body').html(selectBox);
        $('.ba-modal-main_btn').attr('id' , 'save_new_owner');
        $('#ba_custom_cal_modal').modal('toggle');
        return false;
    } else if(operation == 'postpone'){
        $('#ba_cal_modal_header').html('Postpone task');
        var listUsers = getUserList();
        selectBox = '<label> Postpone type: </label> <select name="postpone_type" id="postpone_type" > <option> Minutes </option> <option> Days </option> </select> <br> <label> Length </label> <input type="number" min="1" name="postpone" id="postpone_value"> </input>';
        $('#ba_cal_modal_body').html(selectBox);
        $('.ba-modal-main_btn').attr('id' , 'save_new_postpone');
        $('#ba_custom_cal_modal').modal('toggle');
        return false;
    }

    baAdvanceFuncitonPost(operation , selectedRecords ); 
});

$(document).on('click' , '#save_new_name', function(){
    var newName = $('#new_task_name').val();
    if(newName){
        $(this).removeAttr('id');
        $('#ba_custom_cal_modal').modal('toggle');
        baAdvanceFuncitonPost('rename' , newName);
    }
});

$(document).on('click' , '#save_new_owner', function(){
    var newOwner = $('#new_owner').val();
    if(newOwner){
        $(this).removeAttr('id');
        $('#ba_custom_cal_modal').modal('toggle');
        baAdvanceFuncitonPost('assign_to' , newOwner);
    }
});

$(document).on('click' , '#save_new_postpone', function(){
    var newValue = $('#postpone_value').val();
    var postponeType = $('#postpone_type').val();
    if(newValue){
        var value = {'type': postponeType , 'value': newValue};
        $(this).removeAttr('id');
        $('#ba_custom_cal_modal').modal('toggle');
        baAdvanceFuncitonPost('postpone' , value );
    }
});


function getUserList(){
    $.ajax({
        type: 'POST',
        data: {
            'operation': 'getUserList',
        },
        url: 'index.php?module=Calendar&action=BaFunction',
        success: function(response){
            $('#new_owner').append(response);
        }
    });
}

function baAdvanceFuncitonPost( operation , value = '' ){
    var selectedRecords = [];
    $("input:checkbox[class=listViewEntriesCheckBox]:checked").each(function(){
        selectedRecords.push($(this).val());
    });

    $.ajax({
        type: 'POST',
        data: {
            'selectedRecords': selectedRecords,
            'operation': operation,
            'value': value,
        },
        url: 'index.php?module=Calendar&action=BaFunction',
        success:function(response){
            window.location.reload();

        }
    });
}

// Tasks Postpone script
$(document).on( 'click' ,'div.dropdown-menu.ba_postpone-popover', function(event){
    $(this).parent('.postpone-popover').addClass('open');
});

$(document).on('click' , '#save_postpone_duration', function(e){
    e.preventDefault();
    var obj = this;
    var name = [];
    var value = [];
    var form_data = $(this).closest('#postpone_from_inputs').serializeArray();
    $.each(form_data, function (key, input) {
        name.push(input.name)
        value.push(input.value);
    });

    $.ajax({
        type: 'GET',
        data:{
            'fieldName': name,
            'fieldValue': value,
            },
        url: 'index.php?module=Calendar&action=PostponeReminder',
        success: function(response){
            $(obj).closest('.vtReminder').remove();
        }
    });
});

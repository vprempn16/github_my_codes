<?php

class Calendar_BaFunction_Action extends Vtiger_SaveAjax_Action {

	public function process(Vtiger_Request $request) {
        global $adb;
	    $selectedRecords = $_POST['selectedRecords'];
        $operation = $_POST['operation'];
        $moduleName = 'Calendar';
        $tabid = getTabid($moduleName);

        $fieldValue = $_POST['value'] ;
        $fieldName = '';
        switch ($operation){
            case "copy":
                $fieldList = [];
                $getColumnNameList = $adb->pquery('select fieldname from vtiger_field where tabid = ?' , array($tabid) ); 
                while( $row = $adb->fetch_array($getColumnNameList)){
                    $fieldList[] = $row['fieldname'];
                }
                $exceptFields = [ 'subject', 'createdtime' , 'modifiedtime' ];

                foreach($selectedRecords as $record){
                    $newRecordModal  = Vtiger_Record_Model::getCleanInstance( $moduleName );
                    $recordModel = Vtiger_Record_Model::getInstanceById($record, $moduleName);
                    foreach ($fieldList as $fieldName ) {
                        if(! in_array($fieldName , $exceptFields )){
                            $newRecordModal->set($fieldName, $recordModel->get($fieldName));
                        }
                    }
                    $newRecordModal->set('subject', $recordModel->get('subject').' - Copy');
                    $newRecordModal->save();
                }
                echo true; die;
                break;
            case "change_status":
                $fieldValue = "Completed";
                $fieldName = 'taskstatus';
                break;

            case "rename":
                $fieldName = "subject";
                break;

            case "assign_to":
                $fieldName = "assigned_user_id";
                $this->sendNotification($fieldValue);
                break;
            case 'getUserList':
                $currentUser = Users_Record_Model::getCurrentUserModel();
                $accessibleUsers = $currentUser->getAccessibleUsers();
                $html = '';
                foreach($accessibleUsers as $key => $user){
                    $html .= "<option value='{$key}'> {$user} </option>";
                }
                echo $html; die;
                break;
        }

        foreach($selectedRecords as $record){
            $recordModel = Vtiger_Record_Model::getInstanceById($record, $moduleName);
            if( $fieldName == '' && $operation == 'postpone'){
                $oldValue = $recordModel->get('due_date'); 
                if($fieldValue['type'] == 'Days'){    
                    $newValue = date('Y-m-d', strtotime($oldValue. ' + '.$fieldValue['value'].' days'));
                } else {
                    $newValue = date('Y-m-d H:i', strtotime($oldValue. ' + '.$fieldValue['value'].' munites'));
                }
                $fieldName = 'due_date';
                $fieldValue = $newValue;
            }
            $recordModel->set( $fieldName , $fieldValue );
            $recordModel->set('mode', 'edit');
            $recordModel->save();
        }
        echo true;
    }

    public function sendNotification( $ownerId ){
        global $adb;
        $mailTemplateId = 14;
        $getEmailTemplate = $adb->pquery("select *from vtiger_emailtemplates where templateid = ?" , array( $mailTemplateId ));
        $subject = $adb->query_result($getEmailTemplate , 0, 'subject');
        $body = $adb->query_result($getEmailTemplate , 0, 'body');
        $body = getMergedDescription($body, $ownerId , 'Users');

        $getOwnerMail = $adb->pquery('select email1 from vtiger_users where id = ? ' , array($ownerId) );
        $ownerMail = $adb->query_result($getOwnerMail , 0, 'email1');
        $mail_status = send_mail('Contacts', $ownerMail , $HELPDESK_SUPPORT_NAME, $HELPDESK_SUPPORT_EMAIL_ID, $subject, $body,'','','','','',true);
    }
}

<?php
class Calendar_PostponeReminder_Action extends Vtiger_Action_Controller{


	public function checkPermission(Vtiger_Request $request) {
		$moduleName = $request->getModule();
		$moduleModel = Vtiger_Module_Model::getInstance($moduleName);

		$userPrivilegesModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
		$permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());

		if(!$permission) {
			throw new AppException('LBL_PERMISSION_DENIED');
		}
	}

	public function process(Vtiger_Request $request) {
        global $adb;
        $data = [];
        foreach($_REQUEST['fieldName'] as $key => $name){
            $data[$name] = $_REQUEST['fieldValue'][$key];
        }
        $reminderDate = date('Y-m-d');
        $reminderTime = date('H:i');
        
        if($data['postpone_days']) {
            $next_reminderDate = date('Y-m-d', strtotime("+{$data['postpone_days']} day"));
            $reminderDate = $next_reminderDate;
        } 
        if($data['postpone_hours']) {
            $next_reminderTime = date("H:i", strtotime('+'.$data['postpone_hours'].' hours'));
            $reminderTime = $next_reminderTime;
        } else if($data['postpone_minutes']) {
            $next_reminderTime = date("H:i", strtotime('+'.$data['postpone_minutes'].' minutes'));
            $reminderTime = $next_reminderTime;
        }
        $adb->pquery('delete from vtiger_ba_postpone_remind_task where record_id = ?' , array($data['record_id']));
        $adb->pquery('insert into vtiger_ba_postpone_remind_task (record_id, next_reminder_date , next_reminder_time) values(?,?,?)', array( $data['record_id'], $reminderDate, $reminderTime));
        echo true;
    }
}

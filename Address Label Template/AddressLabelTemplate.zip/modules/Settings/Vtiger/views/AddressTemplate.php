<?php
class Settings_Vtiger_AddressTemplate_View extends Settings_Vtiger_Index_View
{
	public function process(Vtiger_Request $request)
	{
		global $adb;
		$mode = $request->get('mode');
		$module = $request->getModule(false);
		$viewer = $this->getViewer($request);

		if($mode == null) {  
			$getData = $adb->pquery("select id, name from vtiger_ba_address_template", array());
			while($row = $adb->fetch_array($getData)) {
				$temp[$row['id']] = $row['name'];
			}

			if($_POST['call'] == 'ajaxcall') {         
				echo json_encode($temp);
				die;
			}

			$viewer->assign('FILENAME',$temp);
			$viewer->view('ListAddressTemplate.tpl',$module);
		}
		else if($mode == 'create') { 	
			$getContactFields = $adb->pquery('select columnname, fieldlabel from vtiger_field where tabid = 4', array());
			while($row = $adb->fetch_array($getContactFields)) {
				$contactFields[$row['columnname']] = $row['fieldlabel'];
			}

			$record_id = $_GET['id'];
			if($record_id != null) {
				$content = $adb->pquery('select name, content from vtiger_ba_address_template where id = ?',array($record_id));
				$temp = $adb->fetch_array($content);
				$contentTemp = unserialize(base64_decode($temp['content']));
				$viewer->assign('NAME', $temp['name']);
				$viewer->assign('CONTANT', $contentTemp);
				$viewer->assign('RECORD_ID', $record_id);
			}
			$viewer->assign('CONTACTFILEDS', $contactFields);
			$viewer->view('AddressTemplate.tpl', $module);
		}
		else if($mode =='save') { 
			$id = $_POST['record_id'];
			$data = $_POST['CotentTemplate'];
			$filename = $_POST['filename'];
			$encodeData = base64_encode(serialize($data));
			if($id != null) {
				$adb->pquery('update vtiger_ba_address_template set content = ?, name = ? where id = ?',array($encodeData, $filename, $id));
				header('location:index.php?parent=Settings&module=Vtiger&view=AddressTemplate&message=success');
			}
			else {
				$adb->pquery('insert into vtiger_ba_address_template (name, content) values (?, ?)',array($filename, $encodeData));
				header('location:index.php?parent=Settings&module=Vtiger&view=AddressTemplate&message=success');
			}
		}
		else if($mode == 'delete') {
			$id = $_REQUEST['id'];
			$adb->pquery('delete from vtiger_ba_address_template where id = ?', array($id));
			header('location:index.php?parent=Settings&module=Vtiger&view=ContentTemplate&message=deleted');
		}
	}
}

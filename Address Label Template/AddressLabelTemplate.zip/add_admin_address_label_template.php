<?php
include_once 'vtlib/Vtiger/Module.php';
include_once 'includes/main/WebUI.php';

global $adb;
$nextNum = $adb->pquery('select id from vtiger_settings_field_seq');
$fieldId = $adb->fetch_array($nextNum);
$fieldId = $fieldId['id']+1;

//Create admin section	
$adb->pquery("insert into vtiger_settings_field (fieldid,blockid,name,linkto)values($fieldId,3,'Address label templates','index.php?parent=Settings&module=Vtiger&view=AddressTemplate')");

// Update sequence
$adb->pquery("update vtiger_settings_field_seq set id = ?",array($fieldId));
$adb->pquery('create table vtiger_srba_header_template(id int primary key auto_increment,name varchar(100),templates long)');

// Create table for store template
$adb->pquery("CREATE TABLE `vtiger_ba_address_template` ( `id` int(11) NOT NULL AUTO_INCREMENT, `content` mediumtext, `name` varchar(100) DEFAULT NULL, PRIMARY KEY(`id`))");

echo "Done!";
